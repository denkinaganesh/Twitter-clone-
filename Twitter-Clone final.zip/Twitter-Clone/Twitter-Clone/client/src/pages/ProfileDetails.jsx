import React from 'react'
import Profile from '../components/User/Profile'

const ProfileDetails = () => {
  return (
    <div><Profile/></div>
  )
}

export default ProfileDetails