import React from 'react'

const TweetDetails = () => {
  return (
    <div>TweetDetails</div>
  )
}

export default TweetDetails